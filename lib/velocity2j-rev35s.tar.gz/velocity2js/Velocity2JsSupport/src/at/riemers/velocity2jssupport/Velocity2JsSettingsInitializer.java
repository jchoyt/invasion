/*
 * Copyright 2007 Tobias Riemer
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 *
 * http://www.apache.org/licenses/LICENSE-2.0 
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
 **/

package at.riemers.velocity2jssupport;

import java.awt.Color;
import java.awt.Font;
import java.util.Map;
import org.netbeans.editor.BaseImageTokenID;
import org.netbeans.editor.BaseKit;
import org.netbeans.editor.Coloring;
import org.netbeans.editor.Settings;
import org.netbeans.editor.SettingsDefaults;
import org.netbeans.editor.SettingsNames;
import org.netbeans.editor.SettingsUtil;
import org.netbeans.editor.TokenCategory;
import org.netbeans.editor.TokenContext;
import org.netbeans.editor.TokenContextPath;

public class Velocity2JsSettingsInitializer
        extends Settings.AbstractInitializer {
    
    public static final String NAME =
            "velocity-settings-initializer"; // NOI18N
    
    /**
     * Constructor
     */
    public Velocity2JsSettingsInitializer() {
        super(NAME);
    }
    
    /**
     * Update map filled with the settings.
     * @param kitClass kit class for which the settings are being updated.
     *   It is always non-null value.
     * @param settingsMap map holding [setting-name, setting-value] pairs.
     *   The map can be empty if this is the first initializer
     *   that updates it or if no previous initializers updated it.
     */
    public void updateSettingsMap(Class kitClass, Map settingsMap) {
        if (kitClass == BaseKit.class) {
            new VelocityTokenColoringInitializer().
                    updateSettingsMap(kitClass, settingsMap);
        }
        
        if (kitClass == Velocity2JsEditorKit.class) {
            SettingsUtil.updateListSetting(
                    settingsMap,
                    SettingsNames.TOKEN_CONTEXT_LIST,
                    new TokenContext[]
            { Velocity2JsTokenContext.context }
            );
        }
    }
    
    private static class VelocityTokenColoringInitializer extends SettingsUtil.TokenColoringInitializer {
        
        /** Bold font. */
        private static final Font boldFont = SettingsDefaults.defaultFont.deriveFont(Font.BOLD);
        /** Italic font. */
        private static final Font italicFont = SettingsDefaults.defaultFont.deriveFont(Font.ITALIC);
        
        /** Keyword coloring. */
        private static final Coloring keywordsColoring = new Coloring(null, Color.decode("0x0000BB"), null);
        /** identifier coloring. */
        private static final Coloring identifierColoring = new Coloring(boldFont, Color.black, null);
        private static final Coloring textColoring = new Coloring(null, Color.black, null);
        /** string coloring. */
        private static final Coloring stringColoring = new Coloring(null, Color.decode("0x99006B"), null);
        /** string coloring. */
        private static final Coloring charColoring = new Coloring(null, Color.decode("0x99006B"), null);
        /** number coloring. */
        private static final Coloring numberColoring = new Coloring(null, Color.decode("0x780000"), null);
        /** Colon coloring. */
        private static final Coloring operatorsColoring = new Coloring(null, Color.red, null);
        
        /** Empty coloring. */
        private static final Coloring emptyColoring = new Coloring(null, null, null);
        /** Method coloring */
        private static final Coloring methodsColoring = new Coloring(null, Color.decode("0x000077"), null);
        
        private static final Coloring commentColoring = new Coloring(null, Color.decode("0x005500"), null);
        
        private static final Coloring regexpColoring = new Coloring(null, Color.decode("0x333333"), null);
        
        private static final Coloring blockCommentColoring = new Coloring(null, Color.decode("0x005500"), null);
        
        /** Constructs PropertiesTokenColoringInitializer. */
        public VelocityTokenColoringInitializer() {
            super(Velocity2JsTokenContext.context);
        }
        
        /** Gets token coloring. */
        
        
        public Object getTokenColoring(TokenContextPath tokenContextPath,
                TokenCategory tokenIDOrCategory, boolean printingSet) {
            if(!printingSet) {
                
                if(tokenIDOrCategory instanceof BaseImageTokenID){
                    tokenIDOrCategory = ((BaseImageTokenID) tokenIDOrCategory).getCategory();
                }
                
                switch (tokenIDOrCategory.getNumericID()) {
                    case Velocity2JsTokenContext.WHITESPACE_ID:
                        return textColoring;
                    case Velocity2JsTokenContext.TEXT_ID:
                        return emptyColoring;
                    case Velocity2JsTokenContext.LINE_COMMENT_ID:
                        return commentColoring;
                    case Velocity2JsTokenContext.IDENTIFIER_ID:
                        return identifierColoring;
                    case Velocity2JsTokenContext.DIRECTIVE_ID:
                        return keywordsColoring;
                        
                    case Velocity2JsTokenContext.HTML_TEXT_ID:
                    case Velocity2JsTokenContext.HTML_WS_ID:
                        return SettingsDefaults.emptyColoring;
                    case Velocity2JsTokenContext.HTML_ERROR_ID:
                        return new Coloring(null, Color.white, Color.red);
                    case Velocity2JsTokenContext.HTML_TAG_ID:
                        return new Coloring(null, Color.blue, null);
                    case Velocity2JsTokenContext.HTML_ARGUMENT_ID:
                        return new Coloring(null, Color.green.darker().darker(), null);
                    case Velocity2JsTokenContext.HTML_OPERATOR_ID:
                        return new Coloring(null, Color.green.darker().darker(), null);
                    case Velocity2JsTokenContext.HTML_VALUE_ID:
                        return new Coloring(null, new Color(153, 0, 107), null);
                    case Velocity2JsTokenContext.HTML_BLOCK_COMMENT_ID:
                        return new Coloring(italicFont, Coloring.FONT_MODE_APPLY_STYLE,
                                Color.gray, null);
                    case Velocity2JsTokenContext.HTML_SGML_COMMENT_ID:
                        return new Coloring( null, Color.gray, null );
                    case Velocity2JsTokenContext.HTML_DECLARATION_ID:
                        return new Coloring(null, new Color(191, 146, 33), null);
                    case Velocity2JsTokenContext.HTML_CHARACTER_ID:
                        
                        return new Coloring(null, Color.red.darker(), null);
                        
                    default:
                        return emptyColoring;
                }
            } else { // printing set
                return SettingsUtil.defaultPrintColoringEvaluator;
            }
        }
    }
    
}
