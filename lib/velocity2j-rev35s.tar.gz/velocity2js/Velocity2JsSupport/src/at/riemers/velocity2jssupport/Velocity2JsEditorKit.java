/*
 * Copyright 2007 Tobias Riemer
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 *
 * http://www.apache.org/licenses/LICENSE-2.0 
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
 **/

package at.riemers.velocity2jssupport;

import javax.swing.text.Document;
import org.netbeans.editor.BaseDocument;
import org.netbeans.editor.Syntax;
import org.netbeans.editor.SyntaxSupport;
import org.netbeans.modules.editor.NbEditorKit;
import org.openide.ErrorManager;

/**
 *
 * @author tobias
 */
public class Velocity2JsEditorKit extends NbEditorKit {
   
    public static final String MIME_TYPE = "text/x-velocity"; // NOI18N
    
    /** 
     * Creates a new instance of VelocityEditorKit 
     */
    public Velocity2JsEditorKit() { 
    }
    
    /**
     * Create a syntax object suitable for highlighting Velocity file syntax
     */
    public Syntax createSyntax(Document doc) {  
        return new Velocity2JsSyntax();
    }
    
    /**
     * Retrieves the content type for this editor kit
     */
    public String getContentType() {
        return MIME_TYPE;
    }
}
