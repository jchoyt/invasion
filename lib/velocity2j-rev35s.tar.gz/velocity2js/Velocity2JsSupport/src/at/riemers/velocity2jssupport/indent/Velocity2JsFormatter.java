/*
 * Copyright 2007 Tobias Riemer
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 *
 * http://www.apache.org/licenses/LICENSE-2.0 
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
 **/

package at.riemers.velocity2jssupport.indent;

import at.riemers.velocity2jssupport.Velocity2JsSyntax;
import javax.swing.text.BadLocationException;
import org.netbeans.editor.BaseDocument;
import org.netbeans.editor.Syntax;
import org.netbeans.editor.TokenItem;
import org.netbeans.editor.ext.ExtFormatter;
import org.netbeans.editor.ext.ExtSyntaxSupport;
import org.netbeans.editor.ext.html.dtd.DTD;
import org.netbeans.editor.ext.html.dtd.DTD.Element;

/**
 * @author Riemer Tobias
 */
public class Velocity2JsFormatter extends ExtFormatter {
    
    private static final String[] UNFORMATTABLE_TAGS = new String[]{"pre", "script", "code"}; //NOI18N
    
    public Velocity2JsFormatter(Class kitClass) {
        super(kitClass);
    }
    
    
    protected boolean acceptSyntax(Syntax syntax) {
        return (syntax instanceof Velocity2JsSyntax);
    }
   
    
}