/*
 * Copyright 2007 Tobias Riemer
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 *
 * http://www.apache.org/licenses/LICENSE-2.0 
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
 **/

package at.riemers.velocity2jssupport;

import org.netbeans.editor.BaseImageTokenID;
import org.netbeans.editor.BaseTokenCategory;
import org.netbeans.editor.BaseTokenID;
import org.netbeans.editor.TokenContext;
import org.netbeans.editor.TokenContextPath;
import org.netbeans.editor.Utilities;

/**
 *
 * @author tobias
 */
public class Velocity2JsTokenContext  extends TokenContext {
    
    // Numeric-ids for token categories
    public static final int DIRECTIVE_ID = 1; 
    public static final int ERRORS_ID = 2; 
    public static final int INVALID_CHAR_ID = 3;
    public static final int WHITESPACE_ID = 4;
    public static final int TEXT_ID = 5;
    
    public static final int FOREACH_ID = 6;
    public static final int IF_ID = 7;
    public static final int ELSEIF_ID = 8;
    public static final int ELSE_ID = 9;
    public static final int END_ID = 10;      
    public static final int SET_ID = 11;      
    public static final int LINE_COMMENT_ID = 12;
    public static final int IDENTIFIER_ID = 13;
    
    
      // Numeric-ids for token-ids
    public static final int HTML_TEXT_ID = 201;
    public static final int HTML_WS_ID = 202;
    public static final int HTML_ERROR_ID = 203;
    public static final int HTML_TAG_ID = 204;
    public static final int HTML_ARGUMENT_ID = 205;
    public static final int HTML_OPERATOR_ID = 206;
    public static final int HTML_VALUE_ID = 207;
    public static final int HTML_BLOCK_COMMENT_ID = 208;
    public static final int HTML_SGML_COMMENT_ID = 209;
    public static final int HTML_DECLARATION_ID = 210;
    public static final int HTML_CHARACTER_ID = 211;

    public static final int EOL_ID = 12;
    
    public static final int END_OF_LINE_ID = 900;    
    
    // Token-ids

    public static final BaseTokenCategory DIRECTIVE = new BaseTokenCategory("directive", DIRECTIVE_ID); // NOI18N    
    public static final BaseTokenCategory ERRORS = new BaseTokenCategory("errors", ERRORS_ID);
    
    public static final BaseImageTokenID FOREACH = new BaseImageTokenID("directive", FOREACH_ID, DIRECTIVE);
    public static final BaseImageTokenID IF = new BaseImageTokenID("directive", IF_ID, DIRECTIVE);
    public static final BaseImageTokenID ELSEIF = new BaseImageTokenID("directive", ELSEIF_ID, DIRECTIVE);
    public static final BaseImageTokenID ELSE = new BaseImageTokenID("directive", ELSE_ID, DIRECTIVE);
    public static final BaseImageTokenID END = new BaseImageTokenID("directive", END_ID, DIRECTIVE);
    public static final BaseImageTokenID SET = new BaseImageTokenID("directive", SET_ID, DIRECTIVE);
    public static final BaseTokenID TEXT = new BaseTokenID("text", TEXT_ID);
    public static final BaseTokenID IDENTIFIER = new BaseTokenID("identifier", IDENTIFIER_ID);
    public static final BaseTokenID WHITESPACE = new BaseTokenID("whitespace", WHITESPACE_ID); // NOI18N 
    public static final BaseTokenID INVALID_CHAR = new BaseTokenID("invalid-char", INVALID_CHAR_ID, ERRORS); // NOI18N  
    public static final BaseTokenID LINE_COMMENT = new BaseTokenID("line-comment", LINE_COMMENT_ID); // NOI18N
    
    
     // Token-ids
    /** Plain text */
    public static final BaseTokenID HTML_TEXT = new BaseTokenID( "htmltext", HTML_TEXT_ID );
    /** Erroneous Text */
    public static final BaseTokenID HTML_WS = new BaseTokenID( "ws", HTML_WS_ID );
    /** Plain Text*/
    public static final BaseTokenID HTML_ERROR = new BaseTokenID( "error", HTML_ERROR_ID );
    /** Html Tag */
    public static final BaseTokenID HTML_TAG = new BaseTokenID( "tag", HTML_TAG_ID );
    /** Argument of a tag */
    public static final BaseTokenID HTML_ARGUMENT = new BaseTokenID( "argument", HTML_ARGUMENT_ID );
    /** Operators - '=' between arg and value */
    public static final BaseTokenID HTML_OPERATOR = new BaseTokenID( "operator", HTML_OPERATOR_ID );
    /** Value - value of an argument */
    public static final BaseTokenID HTML_VALUE = new BaseTokenID( "value", HTML_VALUE_ID );
    /** Block comment */
    public static final BaseTokenID HTML_BLOCK_COMMENT = new BaseTokenID( "block-comment", HTML_BLOCK_COMMENT_ID );
    /** SGML comment - e.g. in DOCTYPE */
    public static final BaseTokenID HTML_SGML_COMMENT = new BaseTokenID( "sgml-comment", HTML_SGML_COMMENT_ID );
    /** SGML declaration in HTML document - e.g. <!DOCTYPE> */
    public static final BaseTokenID HTML_DECLARATION = new BaseTokenID( "sgml-declaration", HTML_DECLARATION_ID );
    /** Character reference, e.g. &amp;lt; = &lt; */
    public static final BaseTokenID HTML_CHARACTER = new BaseTokenID( "character", HTML_CHARACTER_ID );

    /** End of line */
    public static final BaseTokenID EOL = new BaseTokenID( "EOL", EOL_ID );
    
    /*public static final BaseTokenID END_OF_LINE =
            new BaseTokenID("end-of-line", END_OF_LINE_ID);*/
    
    // Context instance declaration
    public static final Velocity2JsTokenContext context = new Velocity2JsTokenContext();
    public static final TokenContextPath contextPath = context.getContextPath();
    
    /**
     * Construct a new VelocityTokenContext
     */
    private Velocity2JsTokenContext() {
        super("vm-");
        
        try {
            addDeclaredTokenIDs();
        } catch (Exception e) {
            Utilities.annotateLoggable(e);
        }
    }
    
}
