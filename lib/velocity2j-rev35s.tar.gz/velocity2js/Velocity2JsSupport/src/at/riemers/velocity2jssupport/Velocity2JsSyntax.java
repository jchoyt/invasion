/*
 * Copyright 2007 Tobias Riemer
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 *
 * http://www.apache.org/licenses/LICENSE-2.0 
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
 **/

package at.riemers.velocity2jssupport;

import org.netbeans.editor.Syntax;
import org.netbeans.editor.TokenID;

/**
 * @author Tobias Riemer
 */
public class Velocity2JsSyntax extends Syntax {
    
    // Internal states
    private static final int ISI_WHITESPACE = 2; // inside white space
    private static final int ISI_LINE_COMMENT = 4; // inside line comment //
    private static final int ISI_BLOCK_COMMENT = 5; // inside block comment /* ... */
    private static final int ISI_STRING = 6; // inside string constant
    private static final int ISI_STRING_A_BSLASH = 7; // inside string constant after backslash
    private static final int ISI_CHAR = 8; // inside string constant
    private static final int ISI_CHAR_A_BSLASH = 9; // inside string constant after backslash
    private static final int ISI_IDENTIFIER = 10; // inside identifier
    private static final int ISA_SLASH = 11; // slash char
    private static final int ISA_EQ = 12; // after '='
    private static final int ISA_GT = 13; // after '>'
    private static final int ISA_GTGT = 14; // after '>>'
    private static final int ISA_GTGTGT = 15; // after '>>>'
    private static final int ISA_LT = 16; // after '<'
    private static final int ISA_LTLT = 17; // after '<<'
    private static final int ISA_PLUS = 18; // after '+'
    private static final int ISA_MINUS = 19; // after '-'
    
    private static final int ISA_STAR = 20; // after '*'
    private static final int ISA_STAR_I_BLOCK_COMMENT = 21; // after '*'
    private static final int ISA_PIPE = 22; // after '|'
    private static final int ISA_PERCENT = 23; // after '%'
    private static final int ISA_AND = 24; // after '&'
    private static final int ISA_XOR = 25; // after '^'
    private static final int ISA_EXCLAMATION = 26; // after '!'
    private static final int ISA_ZERO = 27; // after '0'
    private static final int ISI_NUMBER = 28; // number
    private static final int ISI_HEX = 32; // hex number
    private static final int ISA_DOT = 33; // after '.'
    private static final int ISA_METHOD = 34; // after method call
    private static final int ISI_REGEXP = 35; // inside RegExp literal
    private static final int ISI_REGEXP_A_BSLASH = 36; // inside RegExp literal after backslash
    private static final int ISI_REGEXP_A_SLASH = 37; // inside RegExp literal after slash
    private static final int ISA_HASH = 40; // after '#'
    private static final int ISA_DOLLAR = 41;
    
    
    
    // Internal states
    private static final int HTML_ISI_TEXT = 201;    // Plain text between tags
    private static final int HTML_ISI_ERROR = 202;   // Syntax error in HTML syntax
    private static final int HTML_ISA_LT = 203;      // After start of tag delimiter - "<"
    private static final int HTML_ISA_SLASH = 204;   // After ETAGO - "</"
    private static final int HTML_ISI_ENDTAG = 205;  // Inside endtag - "</[a..Z]+"
    private static final int HTML_ISP_ENDTAG_X = 206;  // X-switch after ENDTAG's name
    private static final int HTML_ISP_ENDTAG_WS = 207; // In WS in ENDTAG - "</A_ _>"
    private static final int HTML_ISI_TAG = 208;     // Inside tag - "<[a..Z]+"
    private static final int HTML_ISP_TAG_X = 209;   // X-switch after TAG's name
    private static final int HTML_ISP_TAG_WS = 210; // In WS in TAG - "<A_ _...>"
    private static final int HTML_ISI_ARG = 211;    // Inside tag's argument - "<A h_r_...>"
    private static final int HTML_ISP_ARG_X = 212;  // X-switch after ARGUMENT's name
    private static final int HTML_ISP_ARG_WS = 213; // Inside WS after argument awaiting '='
    private static final int HTML_ISP_EQ = 214;     // X-switch after '=' in TAG's ARGUMENT
    private static final int HTML_ISP_EQ_WS = 215;  // In WS after '='
    private static final int HTML_ISI_VAL = 216;    // Non-quoted value
    private static final int HTML_ISI_VAL_QUOT = 217;   // Single-quoted value - may contain " chars
    private static final int HTML_ISI_VAL_DQUOT = 218;  // Double-quoted value - may contain ' chars
    private static final int HTML_ISA_SGML_ESCAPE = 219;  // After "<!"
    private static final int HTML_ISA_SGML_DASH = 220;    // After "<!-"
    private static final int HTML_ISI_HTML_COMMENT = 221; // Somewhere after "<!--"
    private static final int HTML_ISA_HTML_COMMENT_DASH = 222;  // Dash in comment - maybe end of comment
    private static final int HTML_ISI_HTML_COMMENT_WS = 223;  // After end of comment, awaiting end of comment declaration
    private static final int HTML_ISI_SGML_DECL = 224;
    private static final int HTML_ISA_SGML_DECL_DASH = 225;
    private static final int HTML_ISI_SGML_COMMENT = 226;
    private static final int HTML_ISA_SGML_COMMENT_DASH = 227;
    private static final int HTML_ISA_REF = 228;    // when comes to character reference, e.g. &amp;, after &
    private static final int HTML_ISI_REF_NAME = 229; // if the reference is symbolic - by predefined name
    private static final int HTML_ISA_REF_HASH = 230; // for numeric references - after &#
    private static final int HTML_ISI_REF_DEC = 231;  // decimal character reference, e.g. &#345;
    private static final int HTML_ISA_REF_X = 232;    //
    private static final int HTML_ISI_REF_HEX = 233;  // hexadecimal reference, in &#xa.. of &#X9..
    
    
    protected int subState = INIT;
    
    public Velocity2JsSyntax() {
        tokenContextPath = Velocity2JsTokenContext.contextPath;
    }
    
    
    protected TokenID parseToken() {
        char actChar;
        
        while(offset < stopOffset) {
            actChar = buffer[offset];
            
            switch (state) {
                case INIT:
                    switch (actChar) {
                        
                        case '#':
                            state = ISA_HASH;
                            break;
                        case '$':
                            state = ISA_DOLLAR;
                            break;
                            
                            
                            // HTML - BEGIN
                        case '<':
                            state = HTML_ISA_LT;
                            break;
                        case '&':
                            state = HTML_ISA_REF;
                            subState = HTML_ISI_TEXT;
                            break;
                            
                            // HTML - END
                            
                            
                        default:
                            // Check for whitespace
                            if (Character.isWhitespace(actChar)) {
                                state = ISI_WHITESPACE;
                                break;
                            }
                            
                            // Check for identifier
                        /*    if (Character.isJavaIdentifierStart(actChar)) {
                                state = ISI_IDENTIFIER;
                                break;
                            }*/
                            state = HTML_ISI_TEXT;
                            break;
                            //offset++;
                            //return Velocity2JsTokenContext.INVALID_CHAR;
                    }
                    break;
                    
                case ISI_WHITESPACE: // white space
                    if (!Character.isWhitespace(actChar)) {
                        state = INIT;
                        return Velocity2JsTokenContext.WHITESPACE;
                    }
                    break;
                    
                case ISI_LINE_COMMENT:
                    switch (actChar) {
                        case '\n':
                            state = INIT;
                            return Velocity2JsTokenContext.LINE_COMMENT;
                    }
                    break;
                    
                case ISA_DOLLAR:
                    if (!(Character.isJavaIdentifierPart(actChar)) && actChar != '{' && actChar != '.' && actChar != '}') {
                        state = INIT;
                        return Velocity2JsTokenContext.IDENTIFIER;
                    }
                    break;
                    
                case ISA_HASH:
                    switch (actChar) {
                        
                        case '#':
                            state = ISI_LINE_COMMENT;
                            break;
                        default:
                            if (!(Character.isJavaIdentifierPart(actChar))) {
                                state = INIT;
                                TokenID tid = matchKeyword(buffer, tokenOffset, offset - tokenOffset);
                                if(tid != null) return tid;
                                return Velocity2JsTokenContext.TEXT;
                            }
                            break;
                    }
                    break;
                    
                    
                    // HTML - BEGIN
                case HTML_ISI_TEXT:        // DONE
                    switch( actChar ) {
                        case '<':
                        case '&':
                        case '#':
                        case '$':
                            state = INIT;
                            return Velocity2JsTokenContext.HTML_TEXT;
                    }
                    break;
                    
                case HTML_ISI_ERROR:      // DONE
                    offset++;
                    state = INIT;
                    return Velocity2JsTokenContext.HTML_ERROR;
                    
                case HTML_ISA_LT:         // PENDING other transitions - e.g '<?'
                    if( isAZ( actChar ) ) {   // <'a..Z'
                        state = HTML_ISI_TAG;
                        break;
                    }
                    switch( actChar ) {
                        case '/':               // ETAGO - </
                            state = HTML_ISA_SLASH;
                            break;
                        case '>':               // Empty start tag <>, RELAXED
                            offset++;
                            state = INIT;
                            return Velocity2JsTokenContext.HTML_TAG;
                        case '!':
                            state = HTML_ISA_SGML_ESCAPE;
                            break;
                        default:                // Part of text, RELAXED
                            state = HTML_ISI_TEXT;
                            continue;             // don't eat the char, maybe its '&'
                    }
                    break;
                    
                case HTML_ISA_SLASH:        // DONE
                    if( isAZ( actChar ) ) {   // </'a..Z'
                        state = HTML_ISI_ENDTAG;
                        break;
                    }
                    switch( actChar ) {
                        case '>':               // Empty end tag </>, RELAXED
                            offset++;
                            state = INIT;
                            return Velocity2JsTokenContext.HTML_TAG;
                        default:                // Part of text, e.g. </3, </'\n', RELAXED
                            state = HTML_ISI_TEXT;
                            continue;             // don'e eat the char
                    }
                    //break;
                    
                case HTML_ISI_ENDTAG:        // DONE
                    if( isName( actChar ) ) break;    // Still in endtag identifier, eat next char
                    state = HTML_ISP_ENDTAG_X;
                    return Velocity2JsTokenContext.HTML_TAG;
                    
                    
                case HTML_ISP_ENDTAG_X:      // DONE
                    if( isWS( actChar ) ) {
                        state = HTML_ISP_ENDTAG_WS;
                        break;
                    }
                    switch( actChar ) {
                        case '>':               // Closing of endtag, e.g. </H6 _>_
                            offset++;
                            state = INIT;
                            return Velocity2JsTokenContext.HTML_TAG;
                        case '<':               // next tag, e.g. </H6 _<_, RELAXED
                            state = INIT;
                            continue;
                        default:
                            state = HTML_ISI_ERROR;
                            continue; //don't eat
                    }
                    //break;
                    
                case HTML_ISP_ENDTAG_WS:      // DONE
                    if( isWS( actChar ) ) break;  // eat all WS
                    state = HTML_ISP_ENDTAG_X;
                    return Velocity2JsTokenContext.HTML_WS;
                    
                    
                case HTML_ISI_TAG:        // DONE
                    if( isName( actChar ) ) break;    // Still in tag identifier, eat next char
                    state = HTML_ISP_TAG_X;
                    return Velocity2JsTokenContext.HTML_TAG;
                    
                case HTML_ISP_TAG_X:     // DONE
                    if( isWS( actChar ) ) {
                        state = HTML_ISP_TAG_WS;
                        break;
                    }
                    if( isAZ( actChar ) ) {
                        state = HTML_ISI_ARG;
                        break;
                    }
                    switch( actChar ) {
                        case '/':
                        case '>':
                            offset++;
                            state = INIT;
                            return Velocity2JsTokenContext.HTML_TAG;
                        case '<':
                            state = INIT;
                            continue;       // don't eat it!!!
                        default:
                            state = HTML_ISI_ERROR;
                            continue;
                    }
                    //break;
                    
                case HTML_ISP_TAG_WS:        // DONE
                    if( isWS( actChar ) ) break;    // eat all WS
                    state = HTML_ISP_TAG_X;
                    return Velocity2JsTokenContext.HTML_WS;
                    
                case HTML_ISI_ARG:           // DONE
                    if( isName( actChar ) ) break; // eat next char
                    state = HTML_ISP_ARG_X;
                    return Velocity2JsTokenContext.HTML_ARGUMENT;
                    
                case HTML_ISP_ARG_X:
                    if( isWS( actChar ) ) {
                        state = HTML_ISP_ARG_WS;
                        break;
                    }
                    if( isAZ( actChar ) ) {
                        state = HTML_ISI_ARG;
                        break;
                    }
                    switch( actChar ) {
                        case '/':
                        case '>':
                            offset++;
                            state = INIT;
                            return Velocity2JsTokenContext.HTML_TAG;
                        case '<':
                            state = INIT;
                            continue;           // don't eat !!!
                        case '=':
                            offset++;
                            state = HTML_ISP_EQ;
                            return Velocity2JsTokenContext.HTML_OPERATOR;
                        default:
                            state = HTML_ISI_ERROR;
                            continue;
                    }
                    //break;
                    
                case HTML_ISP_ARG_WS:
                    if( isWS( actChar ) ) break;    // Eat all WhiteSpace
                    state = HTML_ISP_ARG_X;
                    return Velocity2JsTokenContext.HTML_WS;
                    
                case HTML_ISP_EQ:
                    if( isWS( actChar ) ) {
                        state = HTML_ISP_EQ_WS;
                        break;
                    }
                    if( isName( actChar ) ) {
                        state = HTML_ISI_VAL;
                        break;
                    }
                    switch( actChar ) {
                        case '\'':
                            state = HTML_ISI_VAL_QUOT;
                            break;
                        case '"':
                            state = HTML_ISI_VAL_DQUOT;
                            break;
                        default:
                            state = HTML_ISI_ERROR;
                            continue;
                    }
                    break;
                    
                case HTML_ISP_EQ_WS:
                    if( isWS( actChar ) ) break;    // Consume all WS
                    state = HTML_ISP_EQ;
                    return Velocity2JsTokenContext.HTML_WS;
                    
                    
                case HTML_ISI_VAL:
                    if( isName( actChar ) ) break;  // Consume whole value
                    state = HTML_ISP_TAG_X;
                    return Velocity2JsTokenContext.HTML_VALUE;
                    
                case HTML_ISI_VAL_QUOT:
                    switch( actChar ) {
                        case '\'':
                            offset++;
                            state = HTML_ISP_TAG_X;
                            return Velocity2JsTokenContext.HTML_VALUE;
                        case '&':
                            if( offset == tokenOffset ) {
                                subState = state;
                                state = HTML_ISA_REF;
                                break;
                            } else {
                                return Velocity2JsTokenContext.HTML_VALUE;
                            }
                    }
                    break;  // else simply consume next char of VALUE
                    
                case HTML_ISI_VAL_DQUOT:
                    switch( actChar ) {
                        case '"':
                            offset++;
                            state = HTML_ISP_TAG_X;
                            return Velocity2JsTokenContext.HTML_VALUE;
                        case '&':
                            if( offset == tokenOffset ) {
                                subState = state;
                                state = HTML_ISA_REF;
                                break;
                            } else {
                                return Velocity2JsTokenContext.HTML_VALUE;
                            }
                    }
                    break;  // else simply consume next char of VALUE
                    
                    
                    
                case HTML_ISA_SGML_ESCAPE:       // DONE
                    if( isAZ(actChar) ) {
                        state = HTML_ISI_SGML_DECL;
                        break;
                    }
                    switch( actChar ) {
                        case '-':
                            state = HTML_ISA_SGML_DASH;
                            break;
                        default:
                            state = HTML_ISI_TEXT;
                            continue;
                    }
                    break;
                    
                case HTML_ISA_SGML_DASH:       // DONE
                    switch( actChar ) {
                        case '-':
                            state = HTML_ISI_HTML_COMMENT;
                            break;
                        default:
                            state = HTML_ISI_TEXT;
                            continue;
                    }
                    break;
                    
                case HTML_ISI_HTML_COMMENT:        // DONE
                    switch( actChar ) {
                        case '-':
                            state = HTML_ISA_HTML_COMMENT_DASH;
                            break;
                    }
                    break;
                    
                case HTML_ISA_HTML_COMMENT_DASH:
                    switch( actChar ) {
                        case '-':
                            state = HTML_ISI_HTML_COMMENT_WS;
                            break;
                        default:
                            state = HTML_ISI_HTML_COMMENT;
                            continue;
                    }
                    break;
                    
                case HTML_ISI_HTML_COMMENT_WS:       // DONE
                    if( isWS( actChar ) ) break;  // Consume all WS
                    switch( actChar ) {
                        case '>':
                            offset++;
                            state = INIT;
                            return Velocity2JsTokenContext.HTML_BLOCK_COMMENT;
                        default:
                            state = HTML_ISI_ERROR;
                            return Velocity2JsTokenContext.HTML_BLOCK_COMMENT;
                    }
                    //break;
                    
                case HTML_ISI_SGML_DECL:
                    switch( actChar ) {
                        case '>':
                            offset++;
                            state = INIT;
                            return Velocity2JsTokenContext.HTML_DECLARATION;
                        case '-':
                            if( offset == tokenOffset ) {
                                state = HTML_ISA_SGML_DECL_DASH;
                                break;
                            } else {
                                return Velocity2JsTokenContext.HTML_DECLARATION;
                            }
                    }
                    break;
                    
                case HTML_ISA_SGML_DECL_DASH:
                    if( actChar == '-' ) {
                        state = HTML_ISI_SGML_COMMENT;
                        break;
                    } else {
                        state = HTML_ISI_SGML_DECL;
                        continue;
                    }
                    
                case HTML_ISI_SGML_COMMENT:
                    switch( actChar ) {
                        case '-':
                            state = HTML_ISA_SGML_COMMENT_DASH;
                            break;
                    }
                    break;
                    
                case HTML_ISA_SGML_COMMENT_DASH:
                    if( actChar == '-' ) {
                        offset++;
                        state = HTML_ISI_SGML_DECL;
                        return Velocity2JsTokenContext.HTML_SGML_COMMENT;
                    } else {
                        state = HTML_ISI_SGML_COMMENT;
                        continue;
                    }
                    
                    
                case HTML_ISA_REF:
                    if( isAZ( actChar ) ) {
                        state = HTML_ISI_REF_NAME;
                        break;
                    }
                    if( actChar == '#' ) {
                        state = HTML_ISA_REF_HASH;
                        break;
                    }
                    state = subState;
                    continue;
                    
                case HTML_ISI_REF_NAME:
                    if( isName( actChar ) ) break;
                    if( actChar == ';' ) offset++;
                    state = subState;
                    return Velocity2JsTokenContext.HTML_CHARACTER;
                    
                case HTML_ISA_REF_HASH:
                    if( actChar >= '0' && actChar <= '9' ) {
                        state = HTML_ISI_REF_DEC;
                        break;
                    }
                    if( actChar == 'x' || actChar == 'X' ) {
                        state = HTML_ISA_REF_X;
                        break;
                    }
                    if( isAZ( actChar ) ) {
                        offset++;
                        state = subState;
                        return Velocity2JsTokenContext.HTML_ERROR;
                    }
                    state = subState;
                    continue;
                    
                case HTML_ISI_REF_DEC:
                    if( actChar >= '0' && actChar <= '9' ) break;
                    if( actChar == ';' ) offset++;
                    state = subState;
                    return Velocity2JsTokenContext.HTML_CHARACTER;
                    
                case HTML_ISA_REF_X:
                    if( (actChar >= '0' && actChar <= '9') ||
                            (actChar >= 'a' && actChar <= 'f') ||
                            (actChar >= 'A' && actChar <= 'F')
                            ) {
                        state = HTML_ISI_REF_HEX;
                        break;
                    }
                    state = subState;
                    return Velocity2JsTokenContext.HTML_ERROR;       // error on previous "&#x" sequence
                    
                case HTML_ISI_REF_HEX:
                    if( (actChar >= '0' && actChar <= '9') ||
                            (actChar >= 'a' && actChar <= 'f') ||
                            (actChar >= 'A' && actChar <= 'F')
                            ) break;
                    if( actChar == ';' ) offset++;
                    state = subState;
                    return Velocity2JsTokenContext.HTML_CHARACTER;
                    // HTML - END
                    
            } // end of switch(state)
            
            offset++;
        } // end of while(offset...)
        
        /** At this stage there's no more text in the scanned buffer.
         * Scanner first checks whether this is completely the last
         * available buffer.
         */
        
        if (lastBuffer) {
            switch(state) {
                case ISI_WHITESPACE:
                    state = INIT;
                    return Velocity2JsTokenContext.WHITESPACE;
                case ISI_IDENTIFIER:
                    state = INIT;
                    TokenID kwd = matchKeyword(buffer, tokenOffset, offset - tokenOffset);
                    return (kwd != null) ? kwd : Velocity2JsTokenContext.TEXT;
                case ISI_LINE_COMMENT:
                    state = INIT;
                    return Velocity2JsTokenContext.LINE_COMMENT;
                case ISA_DOLLAR:
                    state = INIT;
                    return Velocity2JsTokenContext.IDENTIFIER;
            }
        }
        
        /* At this stage there's no more text in the scanned buffer, but
         * this buffer is not the last so the scan will continue on another buffer.
         * The scanner tries to minimize the amount of characters
         * that will be prescanned in the next buffer by returning the token
         * where possible.
         */
        
        switch (state) {
            case ISI_WHITESPACE:
                return Velocity2JsTokenContext.WHITESPACE;
        }
        
        return null; // nothing found
    }
    
    
    
    
    private TokenID matchKeyword(char[] buffer, int offset, int len) {
        
        if (len > 10 || len <= 1) return null;
        
        System.out.println(buffer[offset]);
        offset ++;
        switch (buffer[offset++]) {
            
            case 'f':
                
                return (len == 8
                        && buffer[offset++] == 'o'
                        && buffer[offset++] == 'r'
                        && buffer[offset++] == 'e'
                        && buffer[offset++] == 'a'
                        && buffer[offset++] == 'c'
                        && buffer[offset++] == 'h')
                        ? Velocity2JsTokenContext.FOREACH : null;
                
                
                // end else elseif
            case 'e':
                
                if (len <= 2) return null;
                
                switch (buffer[offset++]) {
                    case 'n':
                        return (len == 4
                                && buffer[offset++] == 'd')
                                ? Velocity2JsTokenContext.END : null;
                        // catch
                    case 'l':
                        
                        if (len == 5
                                && buffer[offset++] == 's'
                                && buffer[offset++] == 'e') {
                            return Velocity2JsTokenContext.ELSE;
                        } else {
                            if (len == 7
                                    && buffer[offset++] == 's'
                                    && buffer[offset++] == 'e'
                                    && buffer[offset++] == 'i'
                                    && buffer[offset++] == 'f') {
                                return Velocity2JsTokenContext.ELSEIF;
                            } else {
                                return null;
                            }
                        }
                    default: return null;
                    
                }
                // if  in instanceof
            case 'i':
                
                switch (buffer[offset++]) {
                    
                    //if
                    case 'f':
                        return (len == 3) ? Velocity2JsTokenContext.IF : null;
                        
                        
                    default: return null;
                }
            case 's':
                
                return (len == 4
                        && buffer[offset++] == 'e'
                        && buffer[offset++] == 't')
                        ? Velocity2JsTokenContext.SET : null;
                
            default: return null;
        }
    }
    
    
    
    
    
    
    
    
    private final boolean isAZ( char ch ) {
        return( (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') );
    }
    
    private final boolean isName( char ch ) {
        return( (ch >= 'a' && ch <= 'z') ||
                (ch >= 'A' && ch <= 'Z') ||
                (ch >= '0' && ch <= '9') ||
                ch == '-' || ch == '_' || ch == '.' || ch == ':' );
        
    }
    
    /**
     * Resolves if given char is whitespace in terms of HTML4.0 specs
     * According to specs, following characters are treated as whitespace:
     * Space - <CODE>'\u0020'</CODE>, Tab - <CODE>'\u0009'</CODE>,
     * Formfeed - <CODE>'\u000C'</CODE>,Zero-width space - <CODE>'\u200B'</CODE>,
     * Carriage return - <CODE>'\u000D'</CODE> and Line feed - <CODE>'\u000A'</CODE>
     * CR's are included for completenes only, they should never appear in document
     */
    
    private final boolean isWS( char ch ) {
        return ( ch == '\u0020' || ch == '\u0009' || ch == '\u000c'
                || ch == '\u200b' || ch == '\n' || ch == '\r' );
    }
    
    
    
}

