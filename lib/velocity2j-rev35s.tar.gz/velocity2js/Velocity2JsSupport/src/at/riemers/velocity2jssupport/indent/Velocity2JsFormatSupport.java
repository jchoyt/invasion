/*
 * Copyright 2007 Tobias Riemer
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 *
 * http://www.apache.org/licenses/LICENSE-2.0 
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
 **/

package at.riemers.velocity2jssupport.indent;

import at.riemers.velocity2jssupport.Velocity2JsTokenContext;
import org.netbeans.editor.TokenContextPath;
import org.netbeans.editor.TokenID;
import org.netbeans.editor.TokenItem;
import org.netbeans.editor.ext.ExtFormatSupport;
import org.netbeans.editor.ext.FormatTokenPosition;
import org.netbeans.editor.ext.FormatWriter;

/** 
 * @author Riemer Tobias
 */
public class Velocity2JsFormatSupport  extends ExtFormatSupport {
    
    private TokenContextPath tokenContextPath;
    
    public Velocity2JsFormatSupport(FormatWriter formatWriter) {
        this(formatWriter, Velocity2JsTokenContext.contextPath);
    }
    
    public Velocity2JsFormatSupport(FormatWriter formatWriter, TokenContextPath tokenContextPath) {
        super(formatWriter);
        this.tokenContextPath = tokenContextPath;
    }
    
    public TokenContextPath getTokenContextPath() {
        return tokenContextPath;
    }
    
    
}