/*
 * Copyright 2007 Tobias Riemer
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 *
 * http://www.apache.org/licenses/LICENSE-2.0 
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License.
 **/

package at.riemers.velocity2jssupport;

import com.sun.org.apache.bcel.internal.util.ClassPath;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;
import java.util.List;
import org.openide.ErrorManager;
import org.openide.loaders.DataNode;
import org.openide.loaders.DataObject;
import org.openide.nodes.Children;
import org.openide.nodes.Node;
import org.openide.nodes.PropertySupport;
import org.openide.nodes.Sheet;
import org.openide.util.Lookup;
import org.openide.util.NbBundle;

public class Velocity2JsDataNode extends DataNode {
    
     private static final String SHEETNAME_TEXT_PROPERTIES = "textProperties"; // NOI18N
    private static final String PROP_ENCODING = "encoding"; // NOI18N

    static final String ATTR_FILE_ENCODING = "Content-Encoding"; // NOI18N
    private static final String IMAGE_ICON_BASE = "at/riemers/velocity2jssupport/icon.gif";
    
    public Velocity2JsDataNode(Velocity2JsDataObject obj) {
        super(obj, Children.LEAF);
        setIconBaseWithExtension(IMAGE_ICON_BASE);
    }
    
    
    
    
    private Node.Property createNameProperty() {
        Node.Property p = new PropertySupport.ReadWrite(
                DataObject.PROP_NAME,
                String.class,
                NbBundle.getMessage(DataObject.class, "PROP_name"),
                NbBundle.getMessage(DataObject.class, "HINT_name")
                ) {
            public Object getValue() {
                return Velocity2JsDataNode.this.getName();
            }
            
            public Object getValue(String key) {
                if ("suppressCustomEditor".equals(key)) { //NOI18N
                    return Boolean.TRUE;
                } else {
                    return super.getValue(key);
                }
            }
            public void setValue(Object val) throws IllegalAccessException,
                    IllegalArgumentException, InvocationTargetException {
                if (!canWrite())
                    throw new IllegalAccessException();
                if (!(val instanceof String))
                    throw new IllegalArgumentException();
                
                Velocity2JsDataNode.this.setName((String)val);
            }
            
            public boolean canWrite() {
                return Velocity2JsDataNode.this.canRename();
            }
            
        };
        
        return p;
    }
    
    protected Sheet createSheet() {
        Sheet sheet = super.createSheet();                
        
        Sheet.Set ps = new Sheet.Set();
        ps.setName(SHEETNAME_TEXT_PROPERTIES);
        ps.setDisplayName(NbBundle.getMessage(Velocity2JsDataNode.class, "PROP_textfileSetName")); // NOI18N
        ps.setShortDescription(NbBundle.getMessage(Velocity2JsDataNode.class, "HINT_textfileSetName")); // NOI18N
        ps.put(new PropertySupport.ReadWrite(PROP_ENCODING,
                String.class, NbBundle.getMessage(Velocity2JsDataNode.class, "PROP_fileEncoding"),
                NbBundle.getMessage(Velocity2JsDataNode.class, "HINT_fileEncoding")) { // NOI18N
            public Object getValue() {
                String enc = (String)getDataObject().getPrimaryFile().getAttribute(ATTR_FILE_ENCODING);
                if (enc == null)
                    return "";
                else
                    return enc;
            }
            
            public void setValue(Object enc) throws InvocationTargetException {
                String encoding = (String)enc;
                if (encoding != null) {
                    if (!"".equals(encoding)) {
                        try {
                            Charset.forName(encoding);
                        } catch (IllegalArgumentException ex) {
                            // IllegalCharsetNameException or UnsupportedCharsetException
                            InvocationTargetException t =  new InvocationTargetException(ex);
                            ErrorManager.getDefault().notify(t);
                            throw t;
                        }
                    } else
                        encoding = null;
                }
                try {
                    getDataObject().getPrimaryFile().setAttribute(ATTR_FILE_ENCODING, encoding);
                    ((Velocity2JsDataObject)getDataObject()).firePropertyChange0(PROP_ENCODING, null, null);
                } catch (IOException ex) {
                    throw new InvocationTargetException(ex);
                }
            }
        });
        sheet.put(ps);
        
        return sheet;
    }
    
    
//    /** Creates a property sheet. */
//    protected Sheet createSheet() {
//        Sheet s = super.createSheet();
//        Sheet.Set ss = s.get(Sheet.PROPERTIES);
//        if (ss == null) {
//            ss = Sheet.createPropertiesSet();
//            s.put(ss);
//        }
//        // TODO add some relevant properties: ss.put(...)
//        return s;
//    }
    
}
